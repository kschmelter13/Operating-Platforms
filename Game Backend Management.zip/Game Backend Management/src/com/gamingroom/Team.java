package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	long id;
	String name;
	
	private List<Player> players = new ArrayList<Player>(); 
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}
	
	public Player addPlayer(String name) {
		Player player = null;
		Iterator<Player> myIt = players.iterator();
		
		if (!myIt.hasNext()) {
			player = new Player(1, name);
		} else {
			while (myIt.hasNext()) {
				Player t = myIt.next();
				if (t.getName().equalsIgnoreCase(name)) {
					System.out.println("Already added");
				}
				else {
					player = new Player(t.getId()+1, name);
				}
			}
		}
		if (player != null) {
			players.add(player);
		}
		return player;
	}
	
	public void printPlayers() {
		for (int i =0; i < players.size(); i++) {
			System.out.println(players.get(i));
		}
	}

	@Override
	public String toString() {
		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
