package com.gamingroom;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p> 
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	long id;
	String name;
	
	private List<Team> teams = new ArrayList<Team>();
	

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name);
	}
	
	public Team addTeam(String name) {
		Team team = null;
		
		Iterator<Team> myIt = teams.iterator();
		
		if (!myIt.hasNext()) {
			team = new Team(1, name);
		} else {
			while (myIt.hasNext()) {
				Team t = myIt.next();
				if (t.getName().equalsIgnoreCase(name)) {
					System.out.println("Already added");
				}
				else {
					team = new Team(t.getId()+1, name);
				}
			}
		}
		if (team != null) {
			teams.add(team);
		}	
		return team;
	}
	
	public void printTeams() {
		for (int i =0; i < teams.size(); i++) {
			System.out.println(teams.get(i));
		}
	}

	@Override
	public String toString() {
		
		return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
	}

}
